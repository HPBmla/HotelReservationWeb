package com.reservation.beans;

public class Customer {

    private String email;
    private String modeOfTraveling;

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getModeOfTraveling() {
        return modeOfTraveling;
    }

    public void setModeOfTraveling(String modeOfTraveling) {
      
        this.modeOfTraveling = modeOfTraveling;
    }

}
