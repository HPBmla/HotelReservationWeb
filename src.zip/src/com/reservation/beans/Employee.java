package com.reservation.beans;

public class Employee extends User {

}
