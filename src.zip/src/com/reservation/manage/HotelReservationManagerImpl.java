package com.reservation.manage;

public class HotelReservationManagerImpl {

}
