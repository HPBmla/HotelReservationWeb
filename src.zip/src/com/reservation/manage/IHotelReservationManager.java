package com.reservation.manage;

public interface IHotelReservationManager {

}
